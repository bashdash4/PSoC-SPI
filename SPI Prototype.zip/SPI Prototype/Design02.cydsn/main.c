/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    SPIS_2_Start();
    
    for(;;)
    {
        /* Place your application code here. */
        
        SPIS_2_ClearTxBuffer();
        SPIS_2_ClearRxBuffer();
        
        int address = SPIS_2_ReadRxData() / 10;
        int data = SPIS_2_ReadRxData() % 10;
        
        //if (SPIS_2_ReadRxData() == 0x34u) //TESTING // no addresses
        if (address == 2)
            {
                if (data == 1)
                {
                    LED_Write(0);
                    CyDelay(500);
                    LED_Write(1);
                    CyDelay(500);
                    //SPIS_2_WriteTxData(0xAAu); //send something back to the master
                }
            }
    }
}

/* [] END OF FILE */
